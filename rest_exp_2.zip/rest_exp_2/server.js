// server.js
// Basic Node.js HTTP server that responds with "Hello REST API"

const http = require('http');

// Create a server
const server = http.createServer((req, res) => {
  res.statusCode = 200; // HTTP status code OK
  res.setHeader('Content-Type', 'text/plain');
  res.end('Hello REST API');
});

// Start the server on port 3000
const PORT = 3000;
server.listen(PORT, () => {
  console.log(`Server running at http://localhost:${PORT}`);
});
